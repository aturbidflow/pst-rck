var app = app || {};

(function(app){
	var dict = {};

	app.translate = function(string){
		return dict[string];
	}

	app.plugins.add('getJSON','translate',
		function(app,onReady){
			lang = document.documentElement.getAttribute('lang');
			if (window.location.search.indexOf('lang') != -1){
				lang = window.location.search.replace(/\??lang=/g,'');
			}
			microAjax(app.api.get('translate/' + lang),function(data){
				dict = JSON.parse(data);
				onReady();
			});
		},
		function(data){
			for (key in dict){
				data = data.replace('{{'+key+'}}',dict[key]);
			}
			return data;
		}
	)
})(app);