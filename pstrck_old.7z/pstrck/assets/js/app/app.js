var BitApp = function(apiUrl){

	function cacheBoost(){
		return Math.round(Math.random() * 1000000);
	}

	var bit = this,
		app = {

/* =================================== API STRUCTURE ==================================== */

		api: {
			config: apiUrl + 'get/config/?v=' + cacheBoost(),
			pages: apiUrl + 'get/config/pages/?v=' + cacheBoost(),
			page: function(name){
				return apiUrl + 'get/page/' + name + '/?v=' + cacheBoost();
			},
			get: function(path){
				return apiUrl + 'get/' + path + '/?v=' + cacheBoost();
			}
		},

/* =================================== CONFIG STRUCTURE ==================================== */

		config: {},
		waiter: {
			count: 0,
			waiting: function(){
				return app.waiter.count != 0;
			},
			wait: function(){
				app.waiter.count++;
			},
			done: function(){
				app.waiter.count--;
				if (app.waiter.count < 0){ app.waiter.count = 0; }
			}
		},

/* =================================== PLUGINS TOOL ==================================== */

		plugins: new function(){
			var points = {};

			function define(name){
				if (!points[name]){
					points[name] = {};
				}
			}

			function addHandler(point,plugin,func){
				define(point);
				if (!points[point][plugin]){
					points[point][plugin] = func;
				}
			}

			this.add = function(point,plugin,init,func){
				init(app,function(){
					addHandler(point,plugin,func);
				});
			}

			this.run = function(point,data,callback){
				for (key in points[point]){
					data = points[point][key](data);
				}

				callback(data);
			}
		},

/* =================================== AJAX GET TOOL ======================================= */

		get: function(url,callback){
			microAjax(url,callback);
		},

		getJSON: function(url,callback){
			microAjax(url,function(data){
				app.plugins.run('getJSON',data,function(data){
					callback(JSON.parse(data));
				});
			})
		},

/* ====================================== CLASSES ========================================== */

		classes: {

        /* -------------------------- CLASS HANDLERS ----------------------------------------*/

			handlers: 
				function(owner){

				/* DEFINES */

					var funcs = {};

				/* PRIVATE */

					function _fire(key)
					{
						return function(e){ funcs[key](e); }
					}

				/* PUBLIC */

					this.define = function(setOfFuncs)
					{
						funcs = setOfFuncs;
					}

					this.trigger = function(name,$scope,$page)
					{
						if (funcs[name]){ funcs[name]($scope,$page); }
					}
				},

            /* ----------------------------------- CLASS PAGE -------------------------------------*/

			page: 
				function(pageInfo,data,onPageReady){

				/* DEFINES */

					var self = this,
						tmpl,
						model = data,
						act = false,
						handlers = new app.classes.handlers(this);

				    Object.defineProperty(self, 'active', 
					    {
							get: function() { return tmpl.hasAttribute('active'); },
							set: function(newVal) { 
								if (newVal){
									tmpl.removeAttribute('previous');
									tmpl.setAttribute('active','');

									handlers.trigger('onActivate', model, tmpl);
								} else {
									if (newVal != self.active){
										tmpl.setAttribute('previous','');

										handlers.trigger('onDeactivate', model, tmpl);
									} else {
										tmpl.removeAttribute('previous');
									}

									tmpl.removeAttribute('active');
								}
							},
							configurable: true
						}
					);

				/* PRIVATE */

					function build(pageInfo,data){
						app.getJSON(
							pageInfo.template + '.tmpl?' + cacheBoost(),
							function(template){
								var options = {
										class: 'screen ' + pageInfo.classes
									};

								tmpl = shaven([
									'#' + pageInfo.id, options,[
										'.screen-container', template
									]
								])[0];

								DataBind.bind(tmpl,data);

								document.body.appendChild(tmpl);
								handlers.trigger('onCreate',model,tmpl);
								onPageReady();
							}
						);
					}

				/* PUBLIC */

					this.setHandlers = function(setOf){
						handlers.define(setOf);
					}

				/* CREATION */

					build(pageInfo,data)

				},

/* --------- CLASS PAGES ---------------*/

			pages: 
				function(){

				/* DEFINES */

					var currentPage,
						self = this,
						busyLoad = false,
						onReady = null,
						totalPages = 0,
						counterPages = 0,
						infos = [],
						pages = [];

				/* PUBLIC */

					this.load = function()
					{
						if (!app.waiter.waiting()){
							app.getJSON(app.api.pages,
								function(res){
									for (key in res.pages){
										res.pages[key].id = key;
										totalPages++;
									}

									infos = res.pages;
									currentPage = res.pages[res.indexPage];

									for (page in infos){
										self.loadPage(infos[page]);
									}
								}
							);
						} else {
							setTimeout(function(){
								self.load();
							},100);
						}
					}

					this.loadPage = function(page)
					{
						if (!busyLoad){
							busyLoad = true;

							app.getJSON(app.api.page(page.api),
								function(data){
									pages[page.id] = new app.classes.page(page,data,function(){
										counterPages++;
										if (counterPages == totalPages && onReady){
											onReady();
										}
									});

									busyLoad = false;
								}
							);
						} else {
							setTimeout(function(){
								self.loadPage(page)
							},100);
						}
					}

					this.setActive = function(name)
					{
						for (key in pages){
							if (key == name){
								pages[key].active = true;
							} else {
								pages[key].active = false;	
							}
						}
					}

					this.setFirst = function()
					{
						self.setActive(currentPage.id);
					}

					this.setHandlers = function(controllers)
					{
						for (key in controllers){
							if (pages[key]){
								pages[key].setHandlers(controllers[key]);
							}
						}
					}

					this.ready = function(callback)
					{
						onReady = callback;
					}

					this.isBusy = function(){
						return busyLoad;
					}
				}

		}
	};

	var pages = new app.classes.pages(),
		controllers = {};

	function setControllers(){
		pages.setHandlers(controllers);
	}

	this.setPage = function(name){
		pages.setActive(name);
		return this;
	}

	this.page = function(name,handlers){
		controllers[name] = handlers;
		return this;
	}

	this.module = function(name){
		$LAB.
			script('/assets/js/app/modules/' + name + '.js').wait(function(){
				app.waiter.done();
			});
		return this;
	}

	this.wait = function(){
		app.waiter.wait();
		return this;
	}

	this.plugins = app.plugins;

	this.run = function(){
		pages.ready(function(){
			setControllers();
			pages.setFirst();
			document.documentElement.removeAttribute('loading');
			document.documentElement.setAttribute('loaded','');
		})
		pages.load();
		return this;
	}
}