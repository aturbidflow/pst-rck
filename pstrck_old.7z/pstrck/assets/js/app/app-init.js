var app;

$LAB
	.setGlobalDefaults({
		CacheBust: true,
		Debug: true
	})

    .script("/assets/js/vendor/ajax.min.js").wait()
    .script("/assets/js/vendor/shaven.min.js").wait()
    .script("/assets/js/vendor/databind.min.js").wait()

    .script("/assets/js/app/app.js")

    .wait(function(){
    	app = new BitApp('/action/');
    	app
    		.module('translate').wait()
    		.page('index',{
    			onCreate: function($scope,$page){
    				$page.addEventListenter('click',function(){
    					app.setPage('add');
    				})
    			},
    			onActivate: function($scope,$page){
    			},
    			onDeactivate: function($scope,$page){
    			}
    		})
    		.page('else',{
    			onActivate: function($scope,$page){
    			},
    			onDeactivate: function($scope,$page){
    			}
    		})
    		.page('add',{
				onActivate: function($scope,$page){
    			},
    			onDeactivate: function($scope,$page){
    			}
    		})
    		.run();
    });